declare module '@trust/keyto'
